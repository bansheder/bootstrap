<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЧОП "Защита"</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.html'; ?>
    <section class="hero-section">
        <h1>Добро пожаловать в ЧОП "Защита"</h1>
        <p>Ваш партнёр в безопасности бизнеса</p>
        <a href="contacts.php" class="btn btn-primary">Связаться с нами</a>
    </section>
    <section class="info-section">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="card info-card">
                        <img src="img/1.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Наши услуги</h5>
                            <p class="card-text">Широкий спектр охранных услуг для вашего бизнеса.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card info-card">
                        <img src="img/2.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">История компании</h5>
                            <p class="card-text">Более 10 лет опыта в сфере безопасности.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card info-card">
                        <img src="img/3.jpg" class="card-img-top" alt="">
                        <div class="card-body">
                            <h5 class="card-title">Контакты</h5>
                            <p class="card-text">Свяжитесь с нами для обсуждения ваших нужд.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include 'footer.html'; ?>
    <script src="bootstrap.min.js"></script>
</body>
</html>
