<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЧОП "Защита"</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.html'; ?>

<section class="history-header">
    <h1>Наша история</h1>
    <p>От создания до лидера в сфере охранных услуг</p>
</section>

<section class="timeline">
    <div class="container">
        <div class="timeline-item">
            <div class="timeline-content">
                <h5>2000 год</h5>
                <p>Основание ЧОП "Защита". Наша миссия – обеспечение безопасности бизнеса.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-content">
                <h5>2005 год</h5>
                <p>Получение первого крупного контракта на охрану промышленных объектов.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-content">
                <h5>2010 год</h5>
                <p>Открытие филиалов в крупных городах России.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-content">
                <h5>2018 год</h5>
                <p>Внедрение современных технологий наблюдения и защиты.</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-content">
                <h5>2023 год</h5>
                <p>Достижение лидерства в рейтингах охранных предприятий страны.</p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.html'; ?>

<script src="bootstrap.min.js"></script>
</body>
</html>
