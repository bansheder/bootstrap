<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЧОП "Защита"</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.html'; ?>

<section class="contact-header">
    <h1>Свяжитесь с нами</h1>
</section>

<section class="contact-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Контактная информация</h2>
                <div class="contact-info">
                    <i class="bi bi-geo-alt-fill"></i> Адрес: г. Москва, ул. Секретная, д. 10
                </div>
                <div class="contact-info">
                    <i class="bi bi-telephone-fill"></i> Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </div>
                <div class="contact-info">
                    <i class="bi bi-envelope-fill"></i> Email: <a href="mailto:info@zashita.ru">info@zashita.ru</a>
                </div>
                <div class="contact-info">
                    <i class="bi bi-clock-fill"></i> Режим работы: Пн-Пт с 9:00 до 18:00
                </div>
            </div>
            <div class="col-md-6 map-container">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.163487866372!2d37.62039331587256!3d55.75396048055414!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x414abcc5f3f4a4b9%3A0x2b9b49c4e441e94b!2z0JDQttCw0YDRiyDQkNC60YHRgtGA0LDQtNCw!5e0!3m2!1sru!2sru!4v1690816080458!5m2!1sru!2sru" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.html'; ?>

<script src="bootstrap.min.js"></script>
</body>
</html>
