<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЧОП "Защита"</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.html'; ?>

<section class="news-header">
    <h1>Новости</h1>
    <p>Будьте в курсе последних событий</p>
</section>

<section class="news-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card news-card">
                    <img src="img/5.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Открытие нового филиала</h5>
                        <p class="card-text">Мы открыли новый офис в Москве! Узнайте больше о предоставляемых услугах.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card news-card">
                    <img src="img/6.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Победа в тендере</h5>
                        <p class="card-text">ЧОП "Защита" выиграл тендер на охрану крупного бизнес-центра.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card news-card">
                    <img src="img/7.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Новые услуги</h5>
                        <p class="card-text">Мы расширили спектр услуг, добавив системы умного наблюдения.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.html'; ?>

<script src="bootstrap.min.js"></script>
</body>
</html>
