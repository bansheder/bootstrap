<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЧОП "Защита"</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'navbar.html'; ?>
    <section class="about-section">
        <div class="container">
            <h1 class="about-title">О нашей компании</h1>
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="about-text">
                        ЧОП "Защита" — это команда профессионалов с более чем 10-летним опытом работы в сфере охраны. 
                        Наша миссия — обеспечить безопасность вашего бизнеса, будь то охрана офисов, складов или коммерческих объектов.
                        Мы гордимся своей репутацией надежного партнёра, который всегда выполняет обязательства.
                    </p>
                    <p class="about-text">
                        Мы работаем как с крупными предприятиями, так и с небольшими компаниями. Наши услуги включают физическую охрану, установку систем видеонаблюдения и мониторинг объектов в режиме 24/7.
                    </p>
                </div>
                <div class="col-md-6">
                    <img src="img/4.jpg" alt="" class="img-fluid about-image">
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.html'; ?>

    <script src="bootstrap.min.js"></script>
</body>
</html>
