<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЧОП "Защита"</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.html'; ?>

<section class="client-header">
    <h1>Для наших клиентов</h1>
    <p>Надежность и безопасность на каждом шаге</p>
</section>

<section class="client-benefits">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="client-benefit-item">
                    <img src="img/8.png" alt="">
                    <h4>Высокий уровень безопасности</h4>
                    <p>Обеспечиваем максимальную защиту вашей собственности и ресурсов.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="client-benefit-item">
                    <img src="img/9.png" alt="">
                    <h4>Профессиональный персонал</h4>
                    <p>Наши сотрудники проходят строгий отбор и обучение, чтобы гарантировать вам лучшую охрану.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="client-benefit-item">
                    <img src="img/10.png" alt="">
                    <h4>Клиент-ориентированный подход</h4>
                    <p>Мы всегда учитываем ваши требования и предлагаем индивидуальные решения для вашего бизнеса.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="client-process">
    <div class="container">
        <h2 class="text-center mb-5">Как мы работаем с клиентами</h2>
        <div class="process-step">
            <div>
                <h5>1. Оценка потребностей</h5>
                <p>Мы внимательно изучаем ваш бизнес, чтобы предложить лучшие решения по безопасности.</p>
            </div>
        </div>
        <div class="process-step">
            <div>
                <h5>2. Разработка стратегии</h5>
                <p>Создаем индивидуальную стратегию защиты с учетом всех ваших потребностей.</p>
            </div>
        </div>
        <div class="process-step">
            <div>
                <h5>3. Реализация</h5>
                <p>Осуществляем внедрение предложенных решений и обеспечиваем контроль на всех этапах.</p>
            </div>
        </div>
        <div class="process-step">
            <div>
                <h5>4. Постоянная поддержка</h5>
                <p>Мы обеспечиваем постоянную поддержку и реагируем на любые изменения в потребностях вашего бизнеса.</p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.html'; ?>

<script src="bootstrap.min.js"></script>
</body>
</html>
