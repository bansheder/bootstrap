<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ЧОП "Защита"</title>
    <link href="bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'navbar.html'; ?>

<section class="info-header">
    <h1>Наши услуги</h1>
    <p>Обеспечение безопасности вашего бизнеса на высшем уровне</p>
</section>

<section class="pricing-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card pricing-card">
                    <div class="card-body">
                        <div class="icon">🔒</div>
                        <h5>Охрана объектов</h5>
                        <p>Профессиональная охрана офисов, складов и других объектов.</p>
                        <p class="price">от 1500 ₽/час</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card">
                    <div class="card-body">
                        <div class="icon">🚚</div>
                        <h5>Сопровождение грузов</h5>
                        <p>Надёжное сопровождение ценных грузов по всей территории РФ.</p>
                        <p class="price">от 2500 ₽/час</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card">
                    <div class="card-body">
                        <div class="icon">📹</div>
                        <h5>Системы видеонаблюдения</h5>
                        <p>Проектирование, установка и обслуживание систем видеонаблюдения.</p>
                        <p class="price">от 50000 ₽</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card pricing-card">
                    <div class="card-body">
                        <div class="icon">🛡️</div>
                        <h5>Личная охрана</h5>
                        <p>Услуги телохранителей для вашей безопасности.</p>
                        <p class="price">от 3000 ₽/час</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card">
                    <div class="card-body">
                        <div class="icon">🎤</div>
                        <h5>Охрана мероприятий</h5>
                        <p>Обеспечение безопасности на любых массовых мероприятиях.</p>
                        <p class="price">от 2000 ₽/час</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card pricing-card">
                    <div class="card-body">
                        <div class="icon">📋</div>
                        <h5>Консультации по безопасности</h5>
                        <p>Анализ рисков и разработка решений по обеспечению безопасности.</p>
                        <p class="price">от 10000 ₽</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="info-footer">
    <div class="container text-center">
        <h2>Ваша безопасность — наша работа</h2>
        <p>Свяжитесь с нами, чтобы узнать больше о наших услугах</p>
    </div>
</section>

<?php include 'footer.html'; ?>

<script src="bootstrap.min.js"></script>
</body>
</html>
